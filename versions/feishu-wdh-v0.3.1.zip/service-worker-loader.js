import './assets/index.ts-BIi_y1ZR.js';
