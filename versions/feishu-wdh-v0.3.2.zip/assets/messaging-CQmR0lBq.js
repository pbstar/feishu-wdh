function s(e){chrome.runtime.sendMessage(e).catch(()=>{})}function n(e){s({type:"PROGRESS",progress:e})}function t(e){const o={type:"EXPORT_DONE",...e};s(o)}export{n as a,t as r};
