const o=`你是需求文档专家。处理文档时，必须：
1. 输出严格符合 GFM 规范的 Markdown。
2. 保留所有图片、代码块、表格、链接等元素，内容零丢失。
3. 剔除乱码以及与需求无关的冗余信息。
4. 禁止修改 UI 文案、提示语、固定话术之类的短语或句子。
5. 统一专业术语，核心概念前后一致。
6. 仅输出正文内容，不添加任何解释或评论。
7. 保持原文语言。`,f={summary:`${o}

任务：将下面的文档提炼为简短的要点摘要，大幅压缩篇幅，突出核心信息与关键结论。可使用标题和列表组织要点。`,perParagraph:`${o}

任务：保留原文的整体结构与段落顺序，对每一段落分别进行精简与去冗余，让表达更凝练，但不要合并或删除段落，也不要丢失关键信息。`,dedupeOnly:`${o}

任务：尽量保留原文的全部含义与结构，仅删除重复、啰嗦、冗余的表达，让文字更干净利落。不要做额外的概括或改写。`};function l(e){return f[e]}const h={summary:.8,perParagraph:.5,dedupeOnly:.2};function y(e){return h[e]}const p="src/offscreen/offscreen.html";async function w(){(await chrome.runtime.getContexts({contextTypes:[chrome.runtime.ContextType.OFFSCREEN_DOCUMENT]})).length>0||await chrome.offscreen.createDocument({url:p,reasons:[chrome.offscreen.Reason.BLOBS],justification:"执行 AI 请求并把导出的 ZIP 转为 Blob URL 以触发下载"})}async function E(e){return await chrome.runtime.sendMessage(e)}const u=3e5;async function d(e,r){const n=[{role:"system",content:l(r.granularity)},{role:"user",content:e}],a=new AbortController,m=setTimeout(()=>a.abort(),u);try{const t=await fetch(r.apiUrl,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${r.apiKey}`},body:JSON.stringify({model:r.model,messages:n,temperature:y(r.granularity),stream:!1}),signal:a.signal});if(!t.ok){let c=`HTTP ${t.status}`;try{const i=await t.json();i.error?.message&&(c=i.error.message)}catch{}throw new Error(`AI 请求失败：${c}`)}const s=(await t.json()).choices?.[0]?.message?.content;if(!s)throw new Error("AI 返回内容为空");return s.trim()}catch(t){throw t.name==="AbortError"?new Error(`AI 请求超时（超过 ${u/1e3} 秒）`):t}finally{clearTimeout(m)}}async function g(e,r){await w();const n=await E({target:"offscreen",type:"SUMMARIZE",markdown:e,config:r});if(!n?.ok||!n.content)throw new Error(n?.error||"AI 处理未返回结果");return n.content}export{g as a,w as e,d as r,E as s};
