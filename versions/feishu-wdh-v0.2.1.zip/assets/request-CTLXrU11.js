const m={optimize:`你是需求文档专家。处理文档时，必须：
1. 输出严格符合 GFM 规范的 Markdown。
2. 保留所有图片、代码块、表格、链接等元素，内容零丢失。
3. 剔除乱码以及与需求无关的冗余信息。
4. 禁止修改 UI 文案、提示语、固定话术之类的短语或句子。
5. 统一专业术语，核心概念前后一致。
6. 仅输出正文内容，不添加任何解释或评论。
7. 保持原文语言。

任务：保留原文的整体结构与段落顺序，对每一段落分别进行精简与去冗余，让表达更凝练，但不要合并或删除段落，也不要丢失关键信息。`,tasks:`你是资深前端研发工程师。请阅读下面的需求文档，梳理出前端研发需要开发的全部任务，输出一份简洁的 Markdown 任务清单。

要求：
1. 按功能模块用 ## 标题分组，模块下用「- [ ] 任务名称」列出任务，一行一条。
2. 任务名精炼概括（10~20 字），确有必要时用括号补充关键限定（涉及页面/组件/接口）。
3. 不展开需求细节，不写验收标准与实施步骤，只输出任务本身。
4. 仅输出任务清单，不添加前言、总结或与文档无关的内容。`};function w(e){return m[e]}const h="src/offscreen/offscreen.html";let o=null;async function y(){return o||(o=E()),o}async function E(){try{if((await chrome.runtime.getContexts({contextTypes:[chrome.runtime.ContextType.OFFSCREEN_DOCUMENT]})).length>0)return;await chrome.offscreen.createDocument({url:h,reasons:[chrome.offscreen.Reason.BLOBS],justification:"执行 AI 请求并把导出的 ZIP 转为 Blob URL 以触发下载"})}finally{o=null}}async function T(e){return await chrome.runtime.sendMessage(e)}const u=3e5;async function p(e,n,s){const r=[{role:"system",content:w(s)},{role:"user",content:e}],a=new AbortController,l=setTimeout(()=>a.abort(),u);try{const t=await fetch(n.apiUrl,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n.apiKey}`},body:JSON.stringify({model:n.model,messages:r,stream:!1}),signal:a.signal});if(!t.ok){let i=`HTTP ${t.status}`;try{const f=await t.json();f.error?.message&&(i=f.error.message)}catch{}throw new Error(`AI 请求失败：${i}`)}const c=(await t.json()).choices?.[0]?.message?.content;if(!c)throw new Error("AI 返回内容为空");return c.trim()}catch(t){throw t.name==="AbortError"?new Error(`AI 请求超时（超过 ${u/1e3} 秒）`):t}finally{clearTimeout(l)}}async function d(e,n,s){await y();const r=await T({target:"offscreen",type:"AI_REQUEST",markdown:e,config:n,purpose:s});if(!r?.ok||!r.content)throw new Error(r?.error||"AI 处理未返回结果");return r.content}export{p as a,y as e,d as r,T as s};
